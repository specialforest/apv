Attention : the motion jpeg 2000 files currently only work with OpenJPEG v0.97 that you can find here : 

http://www.openjpeg.org/openjpeg_v097.tar.gz